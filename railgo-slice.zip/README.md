# RailGo 🚄

Mobile-first train ticket booking web app for a regional rail startup.
Region: China · Currency: CNY (¥) · UI: Chinese (localizable).

This is the **first end-to-end slice**: the full booking happy path plus cancel,
wired across UI → API → DB, with focused tests.

## Stack

- **Next.js 14** (App Router) + TypeScript
- **Prisma** + SQLite for local/sandbox dev (schema is PG-compatible for Vercel/managed Postgres)
- **TanStack Query** for server state (caching, retries, optimistic invalidation)
- **Tailwind CSS** for the mobile-first UI
- **Zod** validation shared across API handlers
- Lightweight **phone-OTP** auth with a signed session cookie

## Run it

```bash
pnpm install
pnpm db:reset      # push schema + seed cities/stations/trips + demo user
pnpm dev           # http://localhost:3000
```

**Demo login:** phone `13800000000`. Tap “获取验证码”, then read the 6-digit
code from the **server terminal** (`[OTP] phone=... code=......`) and enter it.
(OTP delivery is console-only in dev, by design.)

## Booking journey

`/login` → `/` (search) → `/search` (results) → `/trip/[id]/select` (class + qty)
→ `/book` (passengers) → `/order/[id]/confirm` (10-min hold countdown)
→ `/order/[id]/pay` (simulated, success + fail/retry) → `/orders` → `/order/[id]` (cancel + refund).

### Key behaviors

- **Seat inventory** is `class + quantity` per trip (`SeatInventory`), reserved on
  order create and restored on cancel — all inside Prisma transactions so
  `remaining` never goes negative. It hangs off `Trip`, so a real seat-map table
  can be added later without reshaping orders.
- **10-minute hold:** creating an order stamps `holdExpiresAt`; the confirm/pay
  screens show a live countdown. `releaseExpiredHolds()` reclaims abandoned holds.
- **Payment** is simulated (~80% success, or force `success`/`fail` for demos).
  A failed attempt persists its bookkeeping and leaves the order PENDING for retry.
- **Cancel** anytime before departure restores inventory and stamps a simulated refund.

## Tests

```bash
pnpm test
```

Covers: happy path (search → order → pay → list → detail → cancel + inventory
restore), pay fail-then-retry, and the sold-out guard.

## Seed data

6 cities / main HSR stations (北京/上海/广州/深圳/杭州/南京) with G-train trips on
key corridors (京沪、广深、沪杭、京宁) over a rolling 14-day window, finite inventory.

See `docs/FOUNDATION.md` for the full data model, API surface, and scope.
