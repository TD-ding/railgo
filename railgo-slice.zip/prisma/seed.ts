import { PrismaClient } from "@prisma/client";
import { SEAT_CLASSES } from "../src/lib/domain";

const prisma = new PrismaClient();

// Cities -> their main HSR station
const CITIES = [
  { name: "北京", pinyin: "beijing", code: "BJ", station: { name: "北京南", code: "VNP" } },
  { name: "上海", pinyin: "shanghai", code: "SH", station: { name: "上海虹桥", code: "AOH" } },
  { name: "广州", pinyin: "guangzhou", code: "GZ", station: { name: "广州南", code: "IZQ" } },
  { name: "深圳", pinyin: "shenzhen", code: "SZ", station: { name: "深圳北", code: "IOQ" } },
  { name: "杭州", pinyin: "hangzhou", code: "HZ", station: { name: "杭州东", code: "HGH" } },
  { name: "南京", pinyin: "nanjing", code: "NJ", station: { name: "南京南", code: "NKH" } },
];

// Corridors: [fromStationCode, toStationCode, durationMin, priceSecondCents]
const CORRIDORS: [string, string, number, number][] = [
  ["VNP", "AOH", 330, 55300], // 京沪
  ["AOH", "VNP", 330, 55300],
  ["IZQ", "IOQ", 35, 7450], // 广深
  ["IOQ", "IZQ", 35, 7450],
  ["AOH", "HGH", 60, 7350], // 沪杭
  ["HGH", "AOH", 60, 7350],
  ["VNP", "NKH", 215, 44350], // 京宁
  ["NKH", "AOH", 75, 13450], // 宁沪
];

// Daily departure hours per corridor
const DEPART_HOURS = [7, 9, 12, 15, 18];
const DAYS_AHEAD = 14;

function priceFor(seatClass: string, second: number): number {
  if (seatClass === "SECOND") return second;
  if (seatClass === "FIRST") return Math.round(second * 1.6);
  return Math.round(second * 3.1); // BUSINESS
}

function ymd(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

async function main() {
  // Clean (dev only)
  await prisma.payment.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.seatInventory.deleteMany();
  await prisma.trip.deleteMany();
  await prisma.station.deleteMany();
  await prisma.city.deleteMany();
  await prisma.otpCode.deleteMany();
  await prisma.user.deleteMany();

  const stationByCode = new Map<string, string>();
  for (const c of CITIES) {
    const city = await prisma.city.create({
      data: {
        name: c.name,
        pinyin: c.pinyin,
        code: c.code,
        stations: { create: { name: c.station.name, code: c.station.code } },
      },
      include: { stations: true },
    });
    stationByCode.set(c.station.code, city.stations[0].id);
  }

  let trainSeq = 1;
  const today = ymd(new Date());
  let tripCount = 0;

  for (let day = 0; day < DAYS_AHEAD; day++) {
    const date = new Date(today);
    date.setUTCDate(date.getUTCDate() + day);

    for (const [fromCode, toCode, dur, second] of CORRIDORS) {
      const depStationId = stationByCode.get(fromCode)!;
      const arrStationId = stationByCode.get(toCode)!;

      for (const hour of DEPART_HOURS) {
        const trainNo = `G${trainSeq++}`;
        const departAt = new Date(date);
        departAt.setUTCHours(hour, 0, 0, 0);
        const arriveAt = new Date(departAt.getTime() + dur * 60_000);

        await prisma.trip.create({
          data: {
            trainNo,
            date,
            depStationId,
            arrStationId,
            departAt,
            arriveAt,
            inventories: {
              create: SEAT_CLASSES.map((sc) => ({
                seatClass: sc,
                priceCents: priceFor(sc, second),
                total: sc === "BUSINESS" ? 10 : sc === "FIRST" ? 40 : 100,
                remaining: sc === "BUSINESS" ? 10 : sc === "FIRST" ? 40 : 100,
              })),
            },
          },
        });
        tripCount++;
      }
    }
  }

  // Demo user + a ready OTP for review
  const phone = "13800000000";
  await prisma.user.create({ data: { phone, name: "演示用户" } });
  await prisma.otpCode.create({
    data: {
      phone,
      code: "123456",
      expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
    },
  });

  console.log(
    `Seeded ${CITIES.length} cities, ${tripCount} trips over ${DAYS_AHEAD} days.`,
  );
  console.log(`Demo login: phone ${phone}, OTP 123456 (or request a fresh one).`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
