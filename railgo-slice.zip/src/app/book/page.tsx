"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { Button, Card, Field, Header } from "@/components/ui";
import { SEAT_CLASS_LABEL, formatCNY } from "@/lib/domain";
import { loadDraft, clearDraft, type BookingDraft } from "@/lib/draft";
import type { Order } from "@/lib/types";

type Passenger = { name: string; idNo: string };

export default function BookPage() {
  const router = useRouter();
  const [draft, setDraft] = useState<BookingDraft | null>(null);
  const [passengers, setPassengers] = useState<Passenger[]>([]);
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("13800000000");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const d = loadDraft();
    if (!d) {
      router.replace("/");
      return;
    }
    setDraft(d);
    setPassengers(Array.from({ length: d.qty }, () => ({ name: "", idNo: "" })));
  }, [router]);

  if (!draft) return null;

  function update(i: number, key: keyof Passenger, val: string) {
    setPassengers((ps) => ps.map((p, idx) => (idx === i ? { ...p, [key]: val } : p)));
  }

  const valid =
    contactName.trim() &&
    /^1\d{10}$/.test(contactPhone) &&
    passengers.every((p) => p.name.trim() && p.idNo.trim().length >= 4);

  async function submit() {
    if (!draft || !valid) return;
    setErr(null);
    setBusy(true);
    try {
      const { order } = await api.post<{ order: Order }>("/api/orders", {
        tripId: draft.tripId,
        seatClass: draft.seatClass,
        contactName,
        contactPhone,
        passengers,
      });
      clearDraft();
      router.replace(`/order/${order.id}/confirm`);
    } catch (e) {
      const msg = (e as Error).message;
      if (msg.includes("未登录")) {
        router.push(`/login?next=${encodeURIComponent("/book")}`);
        return;
      }
      setErr(msg);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="填写乘客信息" sub={`${draft.trainNo} · ${SEAT_CLASS_LABEL[draft.seatClass]}`} />
      <div className="space-y-4 p-4">
        {passengers.map((p, i) => (
          <Card key={i} className="space-y-3">
            <p className="text-sm font-medium text-gray-700">乘客 {i + 1}</p>
            <Field label="姓名" value={p.name} onChange={(e) => update(i, "name", e.target.value)} placeholder="与证件一致" />
            <Field label="证件号" value={p.idNo} onChange={(e) => update(i, "idNo", e.target.value)} placeholder="身份证/护照号" />
          </Card>
        ))}

        <Card className="space-y-3">
          <p className="text-sm font-medium text-gray-700">联系人</p>
          <Field label="姓名" value={contactName} onChange={(e) => setContactName(e.target.value)} />
          <Field label="手机号" inputMode="numeric" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} />
        </Card>

        {err && <p className="text-sm text-red-600">{err}</p>}
      </div>

      <div className="fixed bottom-16 inset-x-0 mx-auto max-w-md border-t bg-white p-3">
        <div className="mb-2 flex items-center justify-between px-1 text-sm">
          <span className="text-gray-500">合计 {passengers.length} 张</span>
          <span className="text-lg font-semibold text-orange-600">{formatCNY(draft.priceCents * passengers.length)}</span>
        </div>
        <Button onClick={submit} disabled={!valid || busy}>{busy ? "提交中…" : "提交订单"}</Button>
      </div>
    </div>
  );
}
