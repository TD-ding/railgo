import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Providers } from "./providers";
import { TabBar } from "@/components/TabBar";

export const metadata: Metadata = {
  title: "RailGo · 火车票预订",
  description: "区域铁路出行预订",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body>
        <Providers>
          <div className="app-shell">
            <main className="flex-1 pb-16">{children}</main>
            <TabBar />
          </div>
        </Providers>
      </body>
    </html>
  );
}
