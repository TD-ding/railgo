"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/client";
import { Button, Field, Header, Card } from "@/components/ui";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/";
  const [phone, setPhone] = useState("13800000000");
  const [code, setCode] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function sendOtp() {
    setErr(null);
    setBusy(true);
    try {
      await api.post("/api/auth/otp", { phone });
      setSent(true);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function verify() {
    setErr(null);
    setBusy(true);
    try {
      await api.post("/api/auth/verify", { phone, code });
      router.replace(next);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <Header title="登录 RailGo" sub="使用手机号 + 验证码登录" />
      <div className="space-y-4 p-4">
        <Card className="space-y-4">
          <Field
            label="手机号"
            inputMode="numeric"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="请输入手机号"
          />
          {sent && (
            <Field
              label="验证码"
              inputMode="numeric"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="请输入6位验证码"
            />
          )}
          {err && <p className="text-sm text-red-600">{err}</p>}
          {!sent ? (
            <Button onClick={sendOtp} disabled={busy}>
              {busy ? "发送中…" : "获取验证码"}
            </Button>
          ) : (
            <Button onClick={verify} disabled={busy || code.length !== 6}>
              {busy ? "验证中…" : "登录"}
            </Button>
          )}
        </Card>
        <p className="px-1 text-xs text-gray-400">
          演示环境：验证码会输出到服务器终端日志。演示账号 13800000000 可用验证码 123456。
        </p>
      </div>
    </div>
  );
}
