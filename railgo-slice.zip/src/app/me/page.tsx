"use client";

import { useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client";
import { Button, Card, Header } from "@/components/ui";

type Me = { id: string; phone: string; name: string | null };

export default function MePage() {
  const router = useRouter();
  const qc = useQueryClient();
  const { data, error, isLoading } = useQuery({
    queryKey: ["me"],
    queryFn: () => api.get<Me>("/api/auth/me"),
    retry: false,
  });

  async function logout() {
    await api.post("/api/auth/logout");
    qc.clear();
    router.replace("/login");
  }

  return (
    <div>
      <Header title="我的" />
      <div className="space-y-4 p-4">
        {isLoading && <p className="text-center text-gray-400">加载中…</p>}
        {error && (
          <Card className="space-y-3">
            <p className="text-sm text-gray-600">您还未登录。</p>
            <Button onClick={() => router.push("/login?next=/me")}>去登录</Button>
          </Card>
        )}
        {data && (
          <>
            <Card>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">手机号</span>
                <span className="font-medium">{data.phone}</span>
              </div>
            </Card>
            <Button variant="ghost" onClick={logout}>退出登录</Button>
          </>
        )}
      </div>
    </div>
  );
}
