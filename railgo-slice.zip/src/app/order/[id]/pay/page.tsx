"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/client";
import { Button, Card, Header } from "@/components/ui";
import { formatCNY } from "@/lib/domain";
import { useCountdown, mmss } from "@/lib/useCountdown";
import type { Order } from "@/lib/types";

export default function PayPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const { id } = useParams<{ id: string }>();
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const { data } = useQuery({
    queryKey: ["order", id],
    queryFn: () => api.get<{ order: Order }>(`/api/orders/${id}`),
  });
  const order = data?.order;
  const left = useCountdown(order?.holdExpiresAt ?? null);
  const expired = left !== null && left <= 0;

  // `force` lets the demo deterministically exercise both branches.
  async function pay(force?: "success" | "fail") {
    setErr(null);
    setFailed(false);
    setBusy(true);
    try {
      await api.post(`/api/orders/${id}/pay`, force ? { force } : {});
      await qc.invalidateQueries({ queryKey: ["orders"] });
      await qc.invalidateQueries({ queryKey: ["order", id] });
      router.replace(`/order/${id}?paid=1`);
    } catch (e) {
      const msg = (e as Error).message;
      setErr(msg);
      if (msg.includes("支付失败")) {
        setFailed(true);
        // refresh so the displayed attempt count reflects the server state
        await qc.invalidateQueries({ queryKey: ["order", id] });
      }
    } finally {
      setBusy(false);
    }
  }

  if (!order) return <p className="p-8 text-center text-gray-400">加载中…</p>;

  return (
    <div>
      <Header title="支付" sub="模拟支付（演示环境）" />
      <div className="space-y-4 p-4">
        <Card>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">订单金额</span>
            <span className="text-2xl font-semibold text-orange-600">{formatCNY(order.totalCents)}</span>
          </div>
          {order.status === "PENDING" && !expired && left !== null && (
            <p className="mt-2 text-xs text-gray-400">请在 {mmss(left)} 内完成支付</p>
          )}
        </Card>

        {expired && (
          <Card className="bg-red-50">
            <p className="text-sm text-red-600">订单已超时，座位已释放。请重新预订。</p>
          </Card>
        )}

        {failed && (
          <Card className="bg-red-50">
            <p className="text-sm text-red-600">支付失败，请重试。（已尝试 {order.payment?.attempts ?? 0} 次）</p>
          </Card>
        )}
        {err && !failed && <p className="text-sm text-red-600">{err}</p>}

        {!expired && order.status === "PENDING" && (
          <div className="space-y-2">
            <Button onClick={() => pay()} disabled={busy}>{busy ? "支付中…" : failed ? "重试支付" : "确认支付"}</Button>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Button variant="ghost" onClick={() => pay("success")} disabled={busy}>模拟成功</Button>
              <Button variant="ghost" onClick={() => pay("fail")} disabled={busy}>模拟失败</Button>
            </div>
            <p className="text-center text-xs text-gray-400">演示：可强制成功或失败以测试两条路径。</p>
          </div>
        )}
      </div>
    </div>
  );
}
