"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client";
import { Header, Card } from "@/components/ui";
import { fmtTime, fmtDate } from "@/lib/format";
import { ORDER_STATUS_LABEL, formatCNY, type OrderStatus } from "@/lib/domain";
import type { Order } from "@/lib/types";

const statusColor: Record<string, string> = {
  PENDING: "text-orange-600 bg-orange-50",
  PAID: "text-green-600 bg-green-50",
  CANCELLED: "text-gray-500 bg-gray-100",
};

export default function OrdersPage() {
  const router = useRouter();
  const { data, isLoading, error } = useQuery({
    queryKey: ["orders"],
    queryFn: () => api.get<{ orders: Order[] }>("/api/orders"),
    retry: false,
  });

  if (error && (error as Error).message.includes("未登录")) {
    router.replace(`/login?next=${encodeURIComponent("/orders")}`);
    return null;
  }

  const orders = data?.orders ?? [];

  return (
    <div>
      <Header title="我的订单" />
      <div className="space-y-3 p-4">
        {isLoading && <p className="text-center text-gray-400">加载中…</p>}
        {!isLoading && orders.length === 0 && (
          <Card><p className="text-center text-gray-500">还没有订单，去搜索车票吧。</p></Card>
        )}
        {orders.map((o) => {
          const trip = o.items[0]?.trip;
          return (
            <Link key={o.id} href={`/order/${o.id}`}>
              <Card className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{trip?.trainNo}</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs ${statusColor[o.status]}`}>
                    {ORDER_STATUS_LABEL[o.status as OrderStatus]}
                  </span>
                </div>
                {trip && (
                  <div className="flex items-center justify-between text-sm">
                    <span>{trip.depStation.name} → {trip.arrStation.name}</span>
                    <span className="text-gray-400">{fmtDate(trip.departAt)} {fmtTime(trip.departAt)}</span>
                  </div>
                )}
                <div className="flex items-center justify-between border-t pt-2 text-sm">
                  <span className="text-gray-500">{o.items.length} 张</span>
                  <span className="font-semibold text-orange-600">{formatCNY(o.totalCents)}</span>
                </div>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
