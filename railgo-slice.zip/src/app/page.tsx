"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client";
import { Button, Card, Header } from "@/components/ui";
import { upcomingDates } from "@/lib/format";
import type { City } from "@/lib/types";

export default function SearchPage() {
  const router = useRouter();
  const dates = upcomingDates(14);
  const { data } = useQuery({
    queryKey: ["cities"],
    queryFn: () => api.get<{ cities: City[] }>("/api/cities"),
  });
  const cities = data?.cities ?? [];

  const [fromCity, setFromCity] = useState("");
  const [toCity, setToCity] = useState("");
  const [date, setDate] = useState(dates[0].value);

  const fromStations = cities.find((c) => c.id === fromCity)?.stations ?? [];
  const toStations = cities.find((c) => c.id === toCity)?.stations ?? [];
  const [fromStation, setFromStation] = useState("");
  const [toStation, setToStation] = useState("");

  function pickCity(side: "from" | "to", cityId: string) {
    const st = cities.find((c) => c.id === cityId)?.stations ?? [];
    const stationCode = st[0]?.code ?? "";
    if (side === "from") {
      setFromCity(cityId);
      setFromStation(stationCode);
    } else {
      setToCity(cityId);
      setToStation(stationCode);
    }
  }

  function search() {
    const f = fromStation || fromStations[0]?.code;
    const t = toStation || toStations[0]?.code;
    if (!f || !t) return;
    router.push(`/search?from=${f}&to=${t}&date=${date}`);
  }

  const selClass =
    "w-full rounded-xl border border-gray-200 px-3 py-2.5 text-base outline-none focus:border-brand bg-white";

  return (
    <div>
      <Header title="火车票预订" sub="选择出发、到达与日期" />
      <div className="space-y-4 p-4">
        <Card className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="mb-1 block text-sm text-gray-600">出发城市</span>
              <select className={selClass} value={fromCity} onChange={(e) => pickCity("from", e.target.value)}>
                <option value="">选择城市</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block text-sm text-gray-600">到达城市</span>
              <select className={selClass} value={toCity} onChange={(e) => pickCity("to", e.target.value)}>
                <option value="">选择城市</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </label>
          </div>

          {(fromStations.length > 0 || toStations.length > 0) && (
            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="mb-1 block text-sm text-gray-600">出发站</span>
                <select className={selClass} value={fromStation} onChange={(e) => setFromStation(e.target.value)}>
                  {fromStations.map((s) => (
                    <option key={s.id} value={s.code}>{s.name}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="mb-1 block text-sm text-gray-600">到达站</span>
                <select className={selClass} value={toStation} onChange={(e) => setToStation(e.target.value)}>
                  {toStations.map((s) => (
                    <option key={s.id} value={s.code}>{s.name}</option>
                  ))}
                </select>
              </label>
            </div>
          )}

          <label className="block">
            <span className="mb-1 block text-sm text-gray-600">出发日期</span>
            <select className={selClass} value={date} onChange={(e) => setDate(e.target.value)}>
              {dates.map((d) => (
                <option key={d.value} value={d.value}>{d.value} ({d.label})</option>
              ))}
            </select>
          </label>

          <Button onClick={search} disabled={!fromCity || !toCity}>
            查询车票
          </Button>
        </Card>
        <p className="px-1 text-xs text-gray-400">
          演示线路：京沪、广深、沪杭、京宁等高铁车次（未来 14 天）。
        </p>
      </div>
    </div>
  );
}
