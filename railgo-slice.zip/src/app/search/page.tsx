"use client";

import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/client";
import { Header, Card } from "@/components/ui";
import { fmtTime, durationLabel } from "@/lib/format";
import { SEAT_CLASS_LABEL, formatCNY, type SeatClass } from "@/lib/domain";
import type { Trip } from "@/lib/types";

function Results() {
  const params = useSearchParams();
  const from = params.get("from")!;
  const to = params.get("to")!;
  const date = params.get("date")!;

  const { data, isLoading } = useQuery({
    queryKey: ["trips", from, to, date],
    queryFn: () => api.get<{ trips: Trip[] }>(`/api/trips?from=${from}&to=${to}&date=${date}`),
  });

  const trips = data?.trips ?? [];

  return (
    <div>
      <Header title="车次列表" sub={`${date}`} />
      <div className="space-y-3 p-4">
        {isLoading && <p className="text-center text-gray-400">加载中…</p>}
        {!isLoading && trips.length === 0 && (
          <Card>
            <p className="text-center text-gray-500">该线路当天暂无车次，换个日期试试。</p>
          </Card>
        )}
        {trips.map((t) => {
          const minPrice = Math.min(...t.inventories.map((i) => i.priceCents));
          return (
            <Link key={t.id} href={`/trip/${t.id}/select`}>
              <Card className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <div className="text-xl font-semibold">{fmtTime(t.departAt)}</div>
                    <div className="text-xs text-gray-500">{t.depStation.name}</div>
                  </div>
                  <div className="flex-1 px-3 text-center">
                    <div className="text-xs text-gray-400">{durationLabel(t.departAt, t.arriveAt)}</div>
                    <div className="my-1 border-t border-dashed border-gray-300" />
                    <div className="text-xs font-medium text-brand">{t.trainNo}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-semibold">{fmtTime(t.arriveAt)}</div>
                    <div className="text-xs text-gray-500">{t.arrStation.name}</div>
                  </div>
                </div>
                <div className="flex items-center justify-between border-t pt-2">
                  <div className="flex gap-2 text-xs text-gray-500">
                    {t.inventories.map((i) => (
                      <span key={i.id} className={i.remaining > 0 ? "" : "text-gray-300"}>
                        {SEAT_CLASS_LABEL[i.seatClass as SeatClass]}
                        {i.remaining > 0 ? `余${i.remaining}` : "无票"}
                      </span>
                    ))}
                  </div>
                  <div className="text-base font-semibold text-orange-600">
                    {formatCNY(minPrice)}起
                  </div>
                </div>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

export default function SearchResultsPage() {
  return (
    <Suspense fallback={<p className="p-8 text-center text-gray-400">加载中…</p>}>
      <Results />
    </Suspense>
  );
}
