"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const tabs = [
  { href: "/", label: "搜索", icon: "🔍" },
  { href: "/orders", label: "订单", icon: "🎫" },
  { href: "/me", label: "我的", icon: "👤" },
];

export function TabBar() {
  const path = usePathname();
  return (
    <nav className="fixed bottom-0 inset-x-0 mx-auto max-w-md border-t bg-white">
      <div className="grid grid-cols-3">
        {tabs.map((t) => {
          const active = t.href === "/" ? path === "/" : path.startsWith(t.href);
          return (
            <Link
              key={t.href}
              href={t.href}
              className={`flex flex-col items-center py-2 text-xs ${
                active ? "text-brand font-medium" : "text-gray-500"
              }`}
            >
              <span className="text-lg">{t.icon}</span>
              {t.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
