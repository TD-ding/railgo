"use client";

import { clsx } from "clsx";

export function Button({
  className,
  variant = "primary",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "danger";
}) {
  return (
    <button
      className={clsx(
        "w-full rounded-xl py-3 text-base font-medium transition active:scale-[0.99] disabled:opacity-50",
        variant === "primary" && "bg-brand text-white",
        variant === "ghost" && "bg-gray-100 text-gray-700",
        variant === "danger" && "bg-red-50 text-red-600",
        className,
      )}
      {...props}
    />
  );
}

export function Header({ title, sub }: { title: string; sub?: string }) {
  return (
    <header className="bg-brand px-4 pt-6 pb-5 text-white">
      <h1 className="text-xl font-semibold">{title}</h1>
      {sub && <p className="mt-1 text-sm text-white/80">{sub}</p>}
    </header>
  );
}

export function Card({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("rounded-2xl bg-white p-4 shadow-sm", className)}>
      {children}
    </div>
  );
}

export function Field({
  label,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm text-gray-600">{label}</span>
      <input
        className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-base outline-none focus:border-brand"
        {...props}
      />
    </label>
  );
}
