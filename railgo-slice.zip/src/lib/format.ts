export function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Shanghai",
    hour12: false,
  });
}

export function fmtDate(iso: string): string {
  return new Date(iso).toLocaleDateString("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    timeZone: "Asia/Shanghai",
  });
}

export function durationLabel(a: string, b: string): string {
  const min = Math.round((new Date(b).getTime() - new Date(a).getTime()) / 60000);
  const h = Math.floor(min / 60);
  const m = min % 60;
  return `${h}时${m}分`;
}

// next N days as YYYY-MM-DD (Asia/Shanghai-aligned, UTC date keys match seed)
export function upcomingDates(n: number): { value: string; label: string }[] {
  const out: { value: string; label: string }[] = [];
  const now = new Date();
  for (let i = 0; i < n; i++) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + i));
    const value = d.toISOString().slice(0, 10);
    const label = `${d.getUTCMonth() + 1}/${d.getUTCDate()}`;
    out.push({ value, label });
  }
  return out;
}
